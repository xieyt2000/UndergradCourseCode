#ifndef KTH_H
#define KTH_H

#ifdef __cplusplus
extern "C" {
#endif
	
	int compare(int x, int y, int z, int u, int v, int w);
	
	void get_kth(int n, int k, int *x, int *y, int *z);
	
#ifdef __cplusplus
}
#endif

#endif
