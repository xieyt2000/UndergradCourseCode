#ifndef SORT_H
#define SORT_H

#ifdef __cplusplus
extern "C" {
#endif
	
	void sort(int n, int limit, int *a);
	
	void compare(int a, int b, int c, int *max, int *min);
	
#ifdef __cplusplus
}
#endif

#endif
