#pragma once
#include<string>
#include<map>
using std::string;
using std::map;
extern map<string, int> operatorPrecedence;
extern map<string, int> variants;