#pragma once
#include"global_variables.h";
#include<string>
#include<vector>
using std::vector;
using std::string;
void print(int a);
void GenPrecedence();
int operandsToInt(string op);
