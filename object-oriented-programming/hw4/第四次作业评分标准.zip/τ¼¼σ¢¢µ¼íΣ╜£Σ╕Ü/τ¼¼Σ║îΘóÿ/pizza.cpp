#include <algorithm>
#include <iostream>
#include <vector>

#include <cassert>
#include <cmath>

using namespace std;


class Plate {
	string _id;
	class Pizza *pizza;

public:
	Plate(const string &id) : _id(id), pizza(nullptr) {}
	~Plate() {
		cout << "Sold " << _id << " plate." << endl;
	}
	inline bool contains_pizza() const {
		return this->pizza != nullptr;
	}
	inline void hold_pizza(Pizza *pizza) {
		this->pizza = pizza;
	}
	inline const string &id() const {
		return _id;
	}
};

class Pizza {
	Plate *plate;
	string name;
	int ketchup, cheese;
	bool cooked;
	bool cutted;

public:
	Pizza(const string &name, int ketchup, int cheese)
			: name(name), ketchup(ketchup), cheese(cheese), cooked(false), cutted(false), plate(nullptr) {}
	void cook() {
		this->cooked = true;
	}
	void cut() {
		this->cutted = true;
	}
	void put_on(Plate *plate) {
		this->plate = plate;
		plate->hold_pizza(this);
	}
	~Pizza() {
		this->plate->hold_pizza(nullptr);
		cout << "Washed " << this->plate->id() << " plate." << endl;
	}
	void eat() {
		cout << "Eating " << this->name << " (";
		float total = (this->ketchup + this->cheese) / 100.0f;
		if (total == 0.0f) total = 1.0f;
		cout << static_cast<int>(round(this->ketchup / total)) << "% ketchup";
		cout << " and ";
		cout << static_cast<int>(round(this->cheese / total)) << "% cheese";
		if (this->cooked || this->cutted) {
			cout << " that is";
            if (this->cooked) cout << " cooked";
            if (this->cooked && this->cutted) cout << " and";
            if (this->cutted) cout << " cutted";
		}
	    cout << ") from " << this->plate->id() << " plate.";
        cout << endl;
	}
};

struct PizzaConfig {
	string name;
	int ketchup, cheese;
	bool need_cook, need_cut;
};

class PizzaFactory {
	vector<Plate *> plates;
	vector<Pizza *> pizza_served;
public:
	~PizzaFactory() {
		for (Pizza *pizza : this->pizza_served)
			delete pizza;
		for (Plate *plate : this->plates)
			delete plate;
	}
	Pizza *makePizza(const PizzaConfig &config) {
		Plate *empty_plate = nullptr;
		for (Plate *plate : this->plates)
			if (!plate->contains_pizza()) {
				empty_plate = plate;
				break;
			}
		if (empty_plate == nullptr) return nullptr;
		Pizza *pizza = new Pizza(config.name, config.ketchup, config.cheese);
		if (config.need_cook) pizza->cook();
		if (config.need_cut) pizza->cut();
		pizza->put_on(empty_plate);
		this->pizza_served.push_back(pizza);
		return pizza;
	}
	void buyPlate(const string &id) {
		Plate *plate = new Plate(id);
		this->plates.push_back(plate);
	}
	void recyclePizza(Pizza *pizza) {
		assert(pizza != nullptr);
		int index = -1;
		for (int i = 0; i < this->pizza_served.size(); i++)
			if (this->pizza_served[i] == pizza) {
				index = i;
				break;
			}
		assert(index != -1);

		delete pizza;
		this->pizza_served[index] = nullptr;
	}
};

void order_pizza(PizzaFactory &factory,
				 const vector<PizzaConfig> &configs,
				 bool recycle = true) {
	vector<Pizza *> ordered_pizzas;
	for (const PizzaConfig &config : configs) {
        Pizza *pizza = factory.makePizza(config);
        if (pizza == nullptr) break;
        ordered_pizzas.push_back(pizza);
    }
    cout << "Ordered " << ordered_pizzas.size() << " plates of pizza." << endl;
    for (Pizza *pizza : ordered_pizzas) {
        pizza->eat();
        if (recycle) factory.recyclePizza(pizza);
    }
}

int main() {
	PizzaFactory factory;

	vector<string> plate_ids = {
        "red",
        "white",
        "golden",
        "titanium",
        "yellow"
	};

	for (const string &id : plate_ids)
		factory.buyPlate(id);

	vector<PizzaConfig> configs = {
		{"Seafood Pizza", 30, 90, true, true},
		{"Beef Pizza", 20, 40, true, false},
		{"Fruit Pizza", 0, 0, true, false},
		{"Sausage Pizza", 40, 20, true, true},
		{"Tomato Pizza", 20, 0, true, false},
		{"Cheese Pizza", 0, 20, true, true}
	};

	order_pizza(factory, configs, true);
	reverse(configs.begin(), configs.end());
	order_pizza(factory, configs, false);

	return 0;
}





